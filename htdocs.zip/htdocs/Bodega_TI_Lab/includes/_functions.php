<?php
   
require_once ("conx.php");




if (isset($_POST['accion'])){ 
    switch ($_POST['accion']){
        //casos de registros
        case 'editar_registro':
            editar_registro();
            break; 

            case 'eliminar_registro';
            eliminar_registro();
    
            break;

            case 'acceso_user';
            acceso_user();
            break;


		}

	}

    function editar_registro() {
		$conexion=mysqli_connect("localhost","root","","bodega_ti_lab");
		extract($_POST);
		$consulta="UPDATE user SET MarcaModelo = '$MarcaModelo', ESTADO = '$ESTADO', SERIAL = '$SERIAL',
		AF ='$AF', rol = '$rol' WHERE id = '$id' ";

		mysqli_query($conexion, $consulta);


		header('Location: ../views/user.php');

}

function eliminar_registro() {
    $conexion=mysqli_connect("localhost","root","","bodega_ti_lab");
    extract($_POST);
    $id= $_POST['id'];
    $consulta= "DELETE FROM user WHERE id= $id";

    mysqli_query($conexion, $consulta);


    header('Location: ../views/user.php');

}

function acceso_user() {
    $MarcaModelo=$_POST['MarcaModelo'];
    $AF=$_POST['AF'];
    session_start();
    $_SESSION['MarcaModelo']=$MarcaModelo;

    $conexion=mysqli_connect("localhost","root","","bodega_ti_lab");
    $consulta= "SELECT * FROM user WHERE MarcaModelo='$MarcaModelo' AND AF='$AF'";
    $resultado=mysqli_query($conexion, $consulta);
    $filas=mysqli_fetch_array($resultado);


    if($filas['rol'] == 1){ //admin

        header('Location: ../views/user.php');

    }else if($filas['rol'] == 2){//lector
        header('Location: ../views/lector.php');
    }
    
    
    else{

        header('Location: login.php');
        session_destroy();

    }

  
}






