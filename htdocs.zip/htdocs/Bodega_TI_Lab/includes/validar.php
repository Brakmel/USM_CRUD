<?php
$conexion= mysqli_connect("localhost", "root", "", "bodega_ti_lab");

if(isset($_POST['registrar'])){

    if(strlen($_POST['MarcaModelo']) >=1 && strlen($_POST['ESTADO'])  >=1 && strlen($_POST['SERIAL'])  >=1 
    && strlen($_POST['AF'])  >=1 && strlen($_POST['rol']) >= 1 ){

    $MarcaModelo = trim($_POST['MarcaModelo']);
    $ESTADO = trim($_POST['ESTADO']);
    $SERIAL = trim($_POST['SERIAL']);
    $AF = trim($_POST['AF']);
    $rol = trim($_POST['rol']);

    $consulta= "INSERT INTO user (MarcaModelo, ESTADO, SERIAL, AF, rol)
    VALUES ('$MarcaModelo', '$ESTADO','$SERIAL','$AF', '$rol' )";

    mysqli_query($conexion, $consulta);
    mysqli_close($conexion);

    header('Location: ../views/user.php');
  }
}









?>