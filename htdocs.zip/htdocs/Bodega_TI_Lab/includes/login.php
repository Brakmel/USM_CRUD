<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>usm.cl</title>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link rel="icon" href="../img/Logo_UTFSM.ico">
    <link rel="StyleSheet" href="../css/Userphp.css" type="text/css">
</head>
<body>
<header>
  <img src="https://upload.wikimedia.org/wikipedia/commons/4/47/Logo_UTFSM.png">
  <h2 class="h2">Universidad Técnica Federico Santa María</h2>
</header>
<header>
  <h2 class="h2">Campus Vitacura.</h2>
</header>
<form  action="_functions.php" method="POST">
    <div id="login" >
        <div class="container">
            <div id="login-row" class="row justify-content-center align-items-center">
                <div id="login-column" class="col-md-6">
                    <div id="login-box" class="col-md-12">
                        <br><br>
                        <h3 class="text-center">Bodega Laboratorio USM</h3>
                       <br>
                            <div class="form-group">
                                <label for="FUNCIONAL">Usuario:</label><br>
                                <input type="text" name="MarcaModelo" id="MarcaModelo" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="AF">Contraseña:</label><br>
                                <input type="AF" name="AF" id="AF" class="form-control" required>
                                <input type="hidden" name="accion" value="acceso_user">
                            </div>
                            <div class="form-group">
                             <br>
                                <center>
                                <input type="submit"class="btn btn-success" value="Ingresar">   
                                </center>
</form>
                                <center>
                        <a href="../../index.php">Quiero volver al manu principal</a> 
                                </center>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </form>
    <footer>
        <div class="footer_img">
            <a class="a" href="https://www.linkedin.com/in/bran-marcelo-hern%C3%A1ndez-villalobos-2ab428241/"><img src="https://cdn-icons-png.flaticon.com/512/174/174857.png"></a>
            <a class="a" href="https://usmkaptivo.herokuapp.com/htmls/email.php"><img class="correo" src="https://www.hidronor.cl/hidronor/wp-content/uploads/2020/11/icono-mail-desktop.png"></a>
            <a class="a" href="https://www.linkedin.com/in/eduardo-correa-vera-b805554a/"><img src="https://cdn-icons-png.flaticon.com/512/174/174857.png"></a>
        </div>
        <div class="footer_parrafo">
            <a class="a" href="https://www.linkedin.com/in/bran-marcelo-hern%C3%A1ndez-villalobos-2ab428241/"><p>Diseñador web</p></a>
            <a class="a" href="https://usmkaptivo.herokuapp.com/htmls/email.php"><p>Contactarse</p></a>
            <a class="a"href="https://www.linkedin.com/in/eduardo-correa-vera-b805554a/"><p>Jefe de TI</p></a>
        </div>
    </footer>
</body>
</html>