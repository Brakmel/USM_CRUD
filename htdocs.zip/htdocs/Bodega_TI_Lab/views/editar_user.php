<?php

session_start();
error_reporting(0);

$validar = $_SESSION['MarcaModelo'];

if( $validar == null || $validar = ''){

    header("Location: ../includes/login.php");
    die();
    

}





$id= $_GET['id'];
$conexion= mysqli_connect("localhost", "root", "", "bodega_ti_lab");
$consulta= "SELECT * FROM user WHERE id = $id";
$resultado = mysqli_query($conexion, $consulta);
$usuario = mysqli_fetch_assoc($resultado);

?>


<!DOCTYPE html>
<html lang="es-MX">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registros</title>
    <link rel="icon" href="styles/img/Logo_UTFSM.ico">

    <link rel="stylesheet" href="../css/fontawesome-all.min.css">
    <link rel="stylesheet" href="../css/styles.css">
    <link rel="stylesheet" href="../css/es.css">
</head>

<body id="page-top">


<form  action="../includes/_functions.php" method="POST">
<div id="login" >
        <div class="container">
            <div id="login-row" class="row justify-content-center align-items-center">
                <div id="login-column" class="col-md-6">
                    <div id="login-box" class="col-md-12">
                    
                            <br>
                            <br>
                            <h3 class="text-center">Modificar linea</h3>
                            <div class="form-group">
                            <label for="MarcaModelo" class="form-label">Marca modelo:</label>
                            <input type="text"  id="MarcaModelo" name="MarcaModelo" class="form-control" value="<?php echo $usuario['MarcaModelo'];?>"required>
                            </div>
                            <div class="form-group">
                                <label for="username">Funciona:</label><br>
                                <input type="Text" name="ESTADO" id="ESTADO" class="form-control" placeholder="" value="<?php echo $usuario['ESTADO'];?>">
                            </div>
                            <div class="form-group">
                                  <label for="SERIAL" class="form-label">Serial:</label>
                                <input type="Text"  id="SERIAL" name="SERIAL" class="form-control" value="<?php echo $usuario['SERIAL'];?>" required>
                                
                            </div>
                            <div class="form-group">
                                <label for="AF">AF:</label><br>
                                <input type="text" name="AF" id="AF" class="form-control" value="<?php echo $usuario['AF'];?>" required>
                             
                            </div>

                            <div class="form-group">
                                  <label for="rol" class="form-label">Rol</label>
                                <input type="number"  id="rol" name="rol" class="form-control" placeholder="Escribe el rol, 1 admin, 2 lector.." value="<?php echo $usuario['rol'];?>" required>
                                  <input type="hidden" name="accion" value="editar_registro">
                                <input type="hidden" name="id" value="<?php echo $id;?>">
                            </div>
                        
                           <br>

                                <div class="mb-3">
                                    
                                <button type="submit" class="btn btn-success" >Editar</button>
                               <a href="user.php" class="btn btn-danger">Cancelar</a>
                               
                            </div>
                            </div>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </form>
</body>
</html>