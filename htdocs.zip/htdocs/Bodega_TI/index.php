<?php

session_start();
error_reporting(0);

$validar = $_SESSION['MarcaModelo'];

if( $validar == null || $validar = ''){

    header("Location: ./includes/login.php");
    die();
    
    

}



?>
<!DOCTYPE html>
<html lang="es-MX">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>usm.cl</title>

	<link rel="stylesheet" href="./css/es.css">
    <link rel="stylesheet" href="./css/styles.css">
    <link rel="icon" href="img/Logo_UTFSM.ico">
</head>

<body id="page-top">
<div class="modal fade" id="create" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title" id="exampleModalLabel">Agregar a planilla:</h3>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
<form  action="../includes/validar.php" method="POST">

                            <div class="form-group">
                            <label for="MarcaModelo" class="form-label">Marca Modelo:</label>
                            <input type="text"  id="MarcaModelo" name="MarcaModelo" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="username">Funciona:</label><br>
                                <input type="text" name="ESTADO" id="ESTADO" class="form-control" placeholder="">
                            </div>
                            <div class="form-group">
                                  <label for="AF" class="form-label">AF:</label>
                                <input type="text"  id="AF" name="AF" class="form-control" required>
                                
                            </div>
                            <div class="form-group">
                                <label for="SERIAL">Serial:</label><br>
                                <input type="text" name="SERIAL" id="SERIAL" class="form-control" required>
                            </div>
                            
                            <div class="form-group">
                                  <label for="rol" class="form-label">Lector:</label>
                                <input type="number"  id="rol" name="rol" class="form-control" placeholder="Escribe el rol, 1 admin, 2 lector..">
                             
                            </div>
                      
                        
       
                                <div class="mb-3">
                                    
                               <input type="submit" value="Guardar"class="btn btn-success" 
                               name="registrar">
                               <a href="user.php" class="btn btn-danger">Cancelar</a>
                               
                            </div>
                        

                        </form>
               
</body>
</html>