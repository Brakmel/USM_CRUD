<?php

require_once ('../fpdf/fpdf.php');
class PDF extends FPDF
{
// Cabecera de página
function Header()
{
    //$this->image('../img/logo.png', 150, 1, 60); // X, Y, Tamaño
    $this->Ln(20);
    // Arial bold 15
    $this->SetFont('Arial','B', 30);
  
    // Movernos a la derecha
    $this->Cell(60);

    // Título
    $this->Cell(70,10,'Reporte Bodega UTI 2022. ',0,0,'C');
    // Salto de línea
   
    $this->Ln(30);
    $this->SetFont('Arial','B',10);
    $this->SetX(0);
    $this->Cell(41,10,'Marca Modelo',1,0,'C',0);
    $this->Cell(51,10,'Funciona',1,0,'C',0,);
    $this->Cell(41,10,'Serial',1,0,'C',0);
    $this->Cell(41,10,'AF',1,0,'C',0);
    $this->Cell(41,10,'Dia de asignacion',1,0,'C',0);
    $this->Cell(41,10,'Rol',1,1,'C',0);
	

  
}

// Pie de página
function Footer()
{
    // Posición: a 1,5 cm del final
    $this->SetY(-10);
    
    // Arial italic 8
    $this->SetFont('Arial','I',20);
    // Número de página
  
    $this->Cell(0,10,utf8_decode('Página') .$this->PageNo().'/{nb}',0,0,'C');
   //$this->SetFillColor(223, 229,235);
    //$this->SetDrawColor(181, 14,246);
    //$this->Ln(0.5);
}
}

$conexion=mysqli_connect("localhost","root","","bodega_ti");
$consulta = "SELECT user.id, user.MarcaModelo, user.ESTADO, user.AF, user.SERIAL,
user.fecha, permisos.rol FROM user
LEFT JOIN permisos ON user.rol = permisos.id";
$resultado = mysqli_query($conexion, $consulta);

$pdf = new PDF();

$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Arial','',5);
//$pdf->SetWidths(array(10, 30, 27, 27, 20, 20, 20, 20, 22));
while ($row=$resultado->fetch_assoc()) {

    $pdf->SetX(0);

    $pdf->Cell(41,10,$row['MarcaModelo'],1,0,'C',0);
    $pdf->Cell(51,10,$row['ESTADO'],1,0,'C',0);
	$pdf->Cell(41,10,$row['SERIAL'],1,0,'C',0);
    $pdf->Cell(41,10,$row['AF'],1,0,'C',0);
    $pdf->Cell(41,10,$row['fecha'],1,0,'C',0);
    $pdf->Cell(41,10,$row['rol'],1,1,'C',0);
	


} 


	$pdf->Output();
?>