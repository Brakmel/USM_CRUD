<?php

require_once ("conx.php");
header("Content-Type: application/xls");
header("Content-Disposition: attachment; filename=lector.xls");
?>


<table class="table table-striped table-dark " id= "table_id">

                   
<thead>    
<tr>
<th>MARCA MODELO</th>
<th>ESTADO</th>
<th>SERIAL</th>
<th>AF</th>
<th>Rol</th>


</tr>
</thead>
<tbody>

<?php

$conexion=mysqli_connect("localhost","root","","bodega_ti");               
$SQL="SELECT user.id, user.MarcaModelo, user.ESTADO, user.AF, user.SERIAL,
user.fecha, permisos.rol FROM user
LEFT JOIN permisos ON user.rol = permisos.id";
$dato = mysqli_query($conexion, $SQL);

if($dato -> num_rows >0){
while($fila=mysqli_fetch_array($dato)){

?>
<tr>
<td><?php echo $fila['MarcaModelo']; ?></td>
<td><?php echo $fila['ESTADO']; ?></td>
<td><?php echo $fila['SERIAL']; ?></td>
<td><?php echo $fila['fecha']; ?></td>
<td><?php echo $fila['rol']; ?></td>



<?php
}

}
