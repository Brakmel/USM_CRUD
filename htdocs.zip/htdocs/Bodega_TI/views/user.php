<?php
session_start();
error_reporting(0);
$validar = $_SESSION['MarcaModelo'];
if( $validar == null || $validar = ''){
  header("Location: ../includes/login.php");
  die(); 
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/fontawesome-all.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <link rel="StyleSheet" href="../css/Userphp.css" type="text/css">
    <title>usm.cl</title>
    <link rel="icon" href="../img/Logo_UTFSM.ico">
</head>
<!--Esto es la pestaña de administrador.-->
<body class="body">
<div class="">
<header>
  <img src="https://upload.wikimedia.org/wikipedia/commons/4/47/Logo_UTFSM.png">
  <h2 class="h2">Universidad Técnica Federico Santa María</h2>
</header>
<header>
  <h2 class="h2">Campus Vitacura.</h2>
</header>
<div class="col-xs-12">
  		<h1 class="h1">Bienvenido a la bodega Soporte</h1>
  <div>
    <button type="button" class="btn btn-success" data-toggle="modal" data-target="#create">
	  <span class="glyphicon glyphicon-plus"></span> Agregar una fila </a></button>
    <a class="btn btn-warning" href="../includes/_sesion/cerrarSesion.php">Regresar al Lobby</a>
    <a class="btn btn-primary" href="../includes/excel.php">Muestramelo estilo Excel</a>
    <a href="../includes/reporte.php" class="btn btn-primary"><b>Muestramelo estilo PDF</b></a>
  </div>
<div class="container-fluid">
  <form class="d-flex">
			<form action="" method="GET">
			<input class="form-control me-2" type="search" placeholder="Busca por nombre de equipo, funcional o AF" 
      name="busqueda">
			<button class="btn btn-outline-info" type="submit" name="enviar"> <b>Buscar </b> </button> 
	    </form>
</div>
<?php
$conexion=mysqli_connect("localhost","root","","bodega_ti"); 
$where="";

if(isset($_GET['enviar'])){
  $busqueda = $_GET['busqueda'];


	if (isset($_GET['busqueda']))
	{
		$where="WHERE user.ESTADO LIKE'%".$busqueda."%' OR MarcaModelo  LIKE'%".$busqueda."%'
    OR SERIAL  LIKE'%".$busqueda."%'";
	}
  
}

?>
</form>
  <table class="table table-striped table-dark table_id ">
    <thead>    
      <tr>
        <th>Marca modelo</th>
        <th>Funciona</th>
        <th>Serial</th>
        <th>AF</th>
        <th>Día de la asignación</th>
        <th>Acciones</th>
      </tr>
    </thead>
  <tbody>
<?php

$conexion=mysqli_connect("localhost","root","","bodega_ti");               
$SQL="SELECT user.id, user.MarcaModelo, user.ESTADO, user.AF, user.SERIAL,
user.fecha, permisos.rol FROM user
LEFT JOIN permisos ON user.rol = permisos.id $where";
$dato = mysqli_query($conexion, $SQL);

if($dato -> num_rows >0){
    while($fila=mysqli_fetch_array($dato)){
?>
<tr>
<td><?php echo $fila['MarcaModelo']; ?></td>
<td><?php echo $fila['ESTADO']; ?></td>
<td><?php echo $fila['AF']; ?></td>
<td><?php echo $fila['SERIAL']; ?></td>
<td><?php echo $fila['fecha']; ?></td><td>
<a class="btn btn-warning" href="editar_user.php?id=<?php echo $fila['id']?> ">
<i class="fa fa-edit"></i> </a>
<a class="btn btn-danger"  href="eliminar_user.php?id=<?php echo $fila['id']?>">
<i class="fa fa-trash"></i></a>
</td>
</tr>
<?php
}
}else{
?>
  <tr class="text-center">
  <td colspan="16">No existen registros</td>
  </tr>    
<?php   
}
?>
</table>
    <footer>
        <div class="footer_img">
            <a class="a" href="https://www.linkedin.com/in/bran-marcelo-hern%C3%A1ndez-villalobos-2ab428241/"><img src="https://cdn-icons-png.flaticon.com/512/174/174857.png"></a>
            <a class="a" href="https://usmkaptivo.herokuapp.com/htmls/email.php"><img class="ESTADO" src="https://www.hidronor.cl/hidronor/wp-content/uploads/2020/11/icono-mail-desktop.png"></a>
            <a class="a" href="https://www.linkedin.com/in/eduardo-correa-vera-b805554a/"><img src="https://cdn-icons-png.flaticon.com/512/174/174857.png"></a>
        </div>
        <div class="footer_parrafo">
            <a class="a" href="https://www.linkedin.com/in/bran-marcelo-hern%C3%A1ndez-villalobos-2ab428241/"><p>Diseñador web</p></a>
            <a class="a" href="https://usmkaptivo.herokuapp.com/htmls/email.php"><p>Contactarse</p></a>
            <a class="a"href="https://www.linkedin.com/in/eduardo-correa-vera-b805554a/"><p>Jefe de TI</p></a>
        </div>
    </footer>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
  <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.js"></script>
  <script src="../js/user.js"></script>
  <script src="../js/acciones.js"></script>
  <script src="../js/buscador.js"></script>
  <?php include('../index.php'); ?>
</body>
</html>